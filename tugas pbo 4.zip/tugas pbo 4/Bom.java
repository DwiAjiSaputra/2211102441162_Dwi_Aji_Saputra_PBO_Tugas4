import greenfoot.*;

public class Bom extends benda
{
    public void act() 
    {
        setLocation(getX(), getY() + 5);
        meledak();
    }    
    
    public void meledak()
    {
        if (canSee(Katak.class)) // Bom menyentuh kereta
        {
            ((Counter)getWorld().getObjects(Counter.class).get(0)).Counting(-1); // Mengurangi poin
            Greenfoot.playSound("bomb.wav"); // Mainkan suara ledakan bom
            getWorld().removeObject(this); // Hapus objek bom
            Greenfoot.stop(); // Menghentikan permainan
        }
        
        if (atWorldEdge())  // Jika objek berada di luar layar
        {
            getWorld().removeObject(this); // Hapus objek bom
        }
    }
}
