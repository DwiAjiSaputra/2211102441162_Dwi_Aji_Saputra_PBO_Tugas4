import greenfoot.*;

public class Katak extends benda
{
    public void act() 
    {
        moveKereta();
        objectDisappear();
    }    
    
    public void objectDisappear()
    {
        if (canSee(Capung.class))
        {
            eat(Capung.class);
            ((Counter)getWorld().getObjects(Counter.class).get(0)).Counting(10);
            Greenfoot.playSound("score.wav");
        }
    }
    
    public void moveKereta()
    {
        if (Greenfoot.isKeyDown("left"))
        {
            setLocation(getX() - 7, getY()); // Bergerak ke kiri (kurangi posisi X)
        }
        if (Greenfoot.isKeyDown("right"))
        {
            setLocation(getX() + 7, getY()); // Bergerak ke kanan (tambah posisi X)
        }
        if (Greenfoot.isKeyDown("up"))
        {
            setLocation(getX(), getY() - 7); // Bergerak ke atas (kurangi posisi Y)
        }
        if (Greenfoot.isKeyDown("down"))
        {
            setLocation(getX(), getY() + 7); // Bergerak ke bawah (tambah posisi Y)
        }
    }
}
