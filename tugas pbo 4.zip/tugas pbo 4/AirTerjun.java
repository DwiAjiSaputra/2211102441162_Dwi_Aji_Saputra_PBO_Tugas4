import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class langit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AirTerjun extends World
{

    /**
     * Constructor for objects of class langit.
     * 
     */
    public AirTerjun()
    {    
        // Buat world dengan ukuran 720x480 cells dengan cell size 1x1 pixels
        super(720, 480, 1);
        Capungjatuh(); 
        siap(); 
        bomjatuh(); 
        prepare();
    }

    public void act() //method act
    {
        if (getObjects(Capung.class).isEmpty()) Capungjatuh();
        if (getObjects(Bom.class).isEmpty()) bomjatuh();
    }

    private void siap() //method prepare untuk menentukan posisi dari kelas objek masing-masing
    {
        Katak katak = new Katak();
        addObject(katak, 648, 403);
        Counter Counter = new Counter();
        addObject(Counter, 57, 69);
        nilai nilai = new nilai();
        addObject(nilai, 64, 44);
        nilai.setLocation(59, 44);
        katak.setLocation(373, 403);
    }

    public void Capungjatuh() 
    {
        if(Greenfoot.getRandomNumber(2) < 50)
        {
            addObject(new Capung(), Greenfoot.getRandomNumber(519),20);
        }
    }

    public void  bomjatuh() 
    {
        if(Greenfoot.getRandomNumber(2) < 50)
        {
            addObject(new Bom(), Greenfoot.getRandomNumber(519),21);
        }
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}

